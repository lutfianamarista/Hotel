 <div class="header_content" id="header_content">

                <div class="container">
                    <!-- HEADER LOGO -->
                    <div class="header_logo">
                        <a href="<?php echo site_url('');?>"><img src="" alt=""></a>
                    </div>
                    <!-- END / HEADER LOGO -->
                    
                    <!-- HEADER MENU -->
                    <nav class="header_menu">
                        <ul class="menu">
                            <li><a href="<?php echo site_url('');?>">Home</a></li>
                             <li><a href="<?php echo site_url('about');?>">About Us</a></li>
                            <li><a href="<?php echo site_url('rooms');?>">Rooms & Suite</a></li>
                            <li><a href="<?php echo site_url('fasilities');?>">facilities & services</a></li>
							<li><a href="<?php echo site_url('restaurant');?>">restaurants</a></li>
                            <li><a href="<?php echo site_url('reservation');?>">Reservation</a></li>
                            <li><a href="<?php echo site_url('blog');?>">Blog</a></li>
                            <li><a href="<?php echo site_url('contact');?>">Contact Us</a></li>
                        </ul>
                    </nav>
                    <!-- END / HEADER MENU -->

                    <!-- MENU BAR -->
                    <span class="menu-bars">
                        <span></span>
                    </span>
                    <!-- END / MENU BAR -->

                </div>
            </div>