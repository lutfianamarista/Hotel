<footer id="footer">

            <!-- FOOTER BOTTOM -->
            <div class="footer_bottom">
                <div class="container">
                    <p>&copy; <?php echo date('Y');?> Hotel Kelompok 2 All rights reserved | Developed By <a href="http://kelompok2.com/" target="_blank" style="color: #fff;">kelompok 2</a> </p>
                </div>
            </div>
            <!-- END / FOOTER BOTTOM -->

        </footer>